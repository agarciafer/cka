##En todas las mv:
usuario:vagrant
password:vagrant

## Requisitos previos

* Tener instalado [VirtualBox](https://www.virtualbox.org/wiki/Downloads)  `>= 6.1.16`
* Tener instalado [Vagrant](https://www.vagrantup.com/downloads.html) `>= 2.2.10`

## Configuración del cluster

Puede adaptar el cluster a sus necesidades a través de las variables establecidas en el fichero `Vagrantfile`.

```bash
# master node parameters
MASTER_CPU = "2"
MASTER_RAM = "2048"
# node parameters
NODE_COUNT = 2
NODE_CPU = "1"
NODE_RAM = "1024"
# kubernetes parameters
KUBERNETES_VERSION = "1.21.1"
```

## Instalación

Clone el repositorio `git` con el contenido del curso y acceda a la carpeta la carpeta descargada.



Inicie la creación del cluster utilizando el siguiente comando de Vagrant:

```bash
vagrant up
```

La construcción del cluster demora aproximadamente 5 minutos. El tiempo puede variar en dependencia de la velocidad de red.



## Practicar dentro del nodo master, utilizaremos el usuario vagrant:


```bash
vagrant ssh master
```

y compruebe el estado del cluster.

```bash
kubectl get nodes
```

Deberá obtener un resultado similar al siguiente:

```bash
vagrant@master:~$ kubectl get node
NAME     STATUS   ROLES                  AGE   VERSION
master   Ready    control-plane,master   80d   v1.22.1
node1    Ready    <none>                 80d   v1.22.1
node2    Ready    <none>                 80d   v1.21.1



NAME     STATUS   ROLES                  AGE   VERSION   INTERNAL-IP      EXTERNAL-IP   OS-IMAGE             KERNEL-VERSION     CONTAINER-RUNTIME
master   Ready    control-plane,master   80d   v1.22.1   192.168.100.10   <none>        Ubuntu 20.04.1 LTS   5.4.0-52-generic   docker://19.3.9
node1    Ready    <none>                 80d   v1.22.1   192.168.100.11   <none>        Ubuntu 20.04.1 LTS   5.4.0-52-generic   docker://19.3.9
node2    Ready    <none>                 80d   v1.21.1   192.168.100.12


master-->192.168.100.10
node1-->192.168.100.11
node2-->192.168.100.12