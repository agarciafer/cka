kubeadm join 10.0.0.10:6443 --token ketykg.ibvzuvnk6peyxk07 --discovery-token-ca-cert-hash sha256:97f6f4ae5701316a7f9a71ad49a761a82a7d99ffe7683820726e0f54d170ce46 
