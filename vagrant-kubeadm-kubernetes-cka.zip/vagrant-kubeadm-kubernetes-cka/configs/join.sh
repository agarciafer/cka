kubeadm join 10.0.0.10:6443 --token vl9ium.7iq0vmfqlh4c4bvz --discovery-token-ca-cert-hash sha256:67d162adc3e50828d0caead6c2a9d85c09ce2ac202c7518f43ebc4b5ff38a718 
