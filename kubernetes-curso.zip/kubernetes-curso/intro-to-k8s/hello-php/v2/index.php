<?php
echo 'Hello Kubernetes World!'
?>
