kubeadm join 10.0.0.10:6443 --token g8pp5p.03z4jg5diey1eezn --discovery-token-ca-cert-hash sha256:7456f63e2ca033355f79bca3c033f715fccaf2789cedfc8d0dc6439ca4e3a68c 
